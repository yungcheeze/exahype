

// To be done: A generalization for ASCII writers.
